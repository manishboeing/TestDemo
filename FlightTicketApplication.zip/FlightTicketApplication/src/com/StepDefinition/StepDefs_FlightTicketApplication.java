package com.StepDefinition;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs_FlightTicketApplication {
	static WebDriver driver;
	private String today;
	public  String todayInt;
	@Given("Open the Chrome Browser and launch the Flight Booking Portal")
	public void openBrowser(){
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.cleartrip.com//"); 
	}
	@And("Flight Booking Portal opened successfully")
	public void portalOpened()
	{
		System.out.println("Flight booking Portal Cleartrip Opened Successfully");
	}
	@When("User search for given flight source/destination in From and To search field")
	public void searchforFlight()
	{
		driver.findElement(By.id("FromTag")).sendKeys("Bhubaneswar, IN - Biju Patnaik (BBI)");
		driver.findElement(By.id("ToTag")).sendKeys("Bangalore, IN - Kempegowda International Airport (BLR)");
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 today = getCurrentDay();
	        System.out.println("Today's number: " + today + "\n");
	        // click and open the datepicker
	        driver.findElement(By.xpath("//i[@class='icon ir datePicker']")).click();
	        WebElement dateWidgetFrom = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/table/tbody/tr[3]/td[5]"));
	        //This are the columns of the from date picker table
	        List<WebElement> columns = dateWidgetFrom.findElements(By.tagName("td"));
	      //DatePicker is a table. Thus we can navigate to each cell
	        //and if a cell matches with the current date then we will click it.
	        for (WebElement cell: columns) {	
	        	//If you want to click 14th Date
	            if (cell.getText().equals("14")) {
	            
	            //Select Today's Date
	        }
	            if (cell.getText().equals(today)) {
	                cell.click();
	                break;
	            }
	        }
	        try {
	            Thread.sleep(4000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	
	@AfterClass
    public static void quitDriver() {
        driver.quit();
    }
	private String getCurrentDay (){
        //Create a Calendar Object
        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
 
        //Get Current Day as a number
        int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
        System.out.println("Today Int: " + todayInt +"\n");
 
        //Integer to String Conversion
        String todayStr = Integer.toString(todayInt);
        System.out.println("Today Str: " + todayStr + "\n");
 
        return todayStr;
	}
       @And("User enters other details for fields depart on, adults, childrens and infants") 
	   public void selectAdult() throws InterruptedException
       {
    	   Select objSelect = new Select(driver.findElement(By.id("Adults")));
    	   objSelect.selectByIndex(4);
    	   Thread.sleep(2000);
    	   driver.findElement(By.id("SearchBtn")).click();
       }
       @Then("User search for fastest and cheapest travel by entering the date in depart on field")
       public void fastestTravel()
       {
    	   driver.navigate().back();
    	   System.out.println("Today Str: " + todayInt + "\n");
    	   
       }
       @Then("User checks for the evening flight by checking the evening check box present within the departure time arrow")
       public void eveningFlight()
       {
    	   driver.findElement(By.xpath("//*[@id='ResultContainer_1_1']/section[2]/section/aside[1]/div/div[1]/form/div/div[5]/div/nav/ul/li[3]/label")).click();
    	   
       }
      @And("User gets the fastest evening flight")
      public void flightBooked()
      {
    	  driver.findElement(By.xpath("//*[@id='flightForm']/section[2]/div[4]/div/nav/ul/li[2]/table/tbody[2]/tr[2]/td[3]/button")).click();
   	   System.out.println("Ticket is booked successfully");

}

}
      
        
        


        

        
        
    
	
	
	
	
	

    
	        
	        
	        
		
		
		
	


